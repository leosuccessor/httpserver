//-----------------------------------------------------------------------------
// Leo DeAnda, ledeanda
// 2022 Fall CSE130 Assignment 0
// split.c
// Splits given files at given delimiter
// Will print product afterwards
//-----------------------------------------------------------------------------
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// Use buffer size of 1024 bytes.
// No specific reason for 1024.
#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    int read_int;
    char delimeter = *argv[argc - 1];

    // Error handling if not enough arguments are given
    if (argc < 3) {
        fprintf(stderr, "split: not enough arguments\nusage: %s <files> <delimiter>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Error handling if delimeter is more than 1 character
    if (strlen(argv[argc - 1]) != 1) {
        fprintf(stderr,
            "split: only single-character delimiters allowed\nusage: %s <files> <delimiter>\n",
            argv[0]);
        exit(EXIT_FAILURE);
    }

    char buffer[BUFFER_SIZE];
    int bytes;

    // Loop that goes through all given command line arguments
    // and reads all the files
    for (int i = 1; i < argc - 1; i += 1) {

        read_int = open(argv[i], O_RDONLY);

	// Checks if '-' is in the command line,
	// if it is, change read_int to STDIN.
	// Takes user input as file to read
        if (strcmp(argv[i], "-") == 0) {
            read_int = STDIN_FILENO;
        }

	// Used to print error if file is missing
        if (read_int == -1) {
            fprintf(stderr, "split: %s: No such file or directory\n", argv[i]);
        }

	// Loop that is used to write the buffer to stdout
        while ((bytes = read(read_int, buffer, BUFFER_SIZE)) > 0) {

            for (int i = 0; i < bytes; i += 1) {
                if (buffer[i] == delimeter) {
                    buffer[i] = '\n';
                }
            }
            write(1, buffer, bytes);
        }

	// Closes the opened file
        close(read_int);
    }
}
