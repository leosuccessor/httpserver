# Assignment 0 - Split

This program is able to split files or stdin, by a given single character delimiter.\
The size of the buffer used for my implementation of split is 1024.\
I just used what professor Alvaro recommended.\
The structure is nothing special, utilization of 'fprintf' for errors, 'if' statements to check\
for errors and to replace delimiter with newline character, while loops for continuous reading\
of files until EOF and 'for' loop to go through all the command line arguments.

## Building

To build 'split', run the following.
'''
make split
'''

To format the file, run the following.

'''
make format
'''

To clean files after making split, run the following.

'''
make clean
'''


## Running

To run the split, type the following:\

'''
./split (file1) (file2) ... (delimiter)
'''

Delimiter is only allowed to be 1 charcter long.\
File has to exist, or nothing will be read.\
If '-' is typed into the command line, it will take the\
stdin from command line until ended with 'ctrl + d'\
and will continue if there are any files afterwards.
