# This is to test if it will split using other keyboard chars
text="test_files/wonderful.txt"
diff <(./split $text _) <(./rsplit $text _) > /dev/null
printf "wonderful.txt file, with '_' char delimiter\n"
echo $?

diff <(./split $text .) <(./rsplit $text .) > /dev/null
printf "wonderful.txt file, with '.' char delimiter\n"
echo $?

diff <(./split $text 0) <(./rsplit $text 0) > /dev/null
printf "wonderful.txt file, with '0' char delimiter\n"
echo $?
