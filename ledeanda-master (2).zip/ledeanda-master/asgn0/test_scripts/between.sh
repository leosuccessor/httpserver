# This will test to see if '-' can be placed multiple times for input
text="test_files/frankenstein.txt"
text2="test_files/inputfile.txt"
diff <(./split $text - $text - $text - a < $text2) <(./rsplit $text - $text - $text - a < $text2) > /dev/null

echo $?
