# This will test to see if an error will be thrown if no delimiter is given
text="test_files/frankenstein.txt"
diff <(./split $text ) <(./rsplit $text ) > /dev/null
echo $?
