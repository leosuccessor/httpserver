# This will test to see if they match if a file is given then '-' for
# stdin and then '-' for the delimiter
text="test_files/frankenstein.txt"
text2="test_files/inputfile.txt"
diff <(./split $text - - < $text2) <(./rsplit $text - - < $text2) > /dev/null
echo $?
