# This will test to see if they match if none of the files exist
text="sandwhich.txt"
text2="bible.txt"
text3="testingfile.txt"
text4="awesome.txt"
diff <(./split $text $text2 $text3 $text4 a) <(./rsplit $text $text2 $text3 $text4 a) > /dev/null

echo $?
