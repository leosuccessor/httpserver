# Assignment 3 - Logging httpserver

This program takes the httpserver from assignment 1 and implements logging.
It will log the requests that were made in the order that the server is\
processesing them. They will follow the following output\
(Oper), (URI), (Status-Code), (RequestID header value) 'newline'

## Building

To build 'httpserver', run the following.

'''
make httpserver
'''

To format the file, run the following.

'''
make format
'''

To clean files after making split, run the following.

'''
make clean
'''

## Running

To run the httpserver, type the folowing:

'''
./httpserver -t (# of threads) -l (name for audit log) (port number)
'''

If -t was not specified when starting the server, the default number of threads is 4.
If -l was not specified when starting the server, it will output to stderr.

This will start the locally hosted server and you can type the following into a local browser\
to see the server:

'''
localhost:(port number)/(file name)
'''

