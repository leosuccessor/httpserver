for i in $(ls test_scripts); do bash test_scripts/$i; if [ $? -eq 0 ]; then echo -e "\033[0;36mRunning $i: \033[0;32mPASS\033[0m"; else echo -e "\033[0;36mRunning $i: \033[0;31mFAIL\033[0m"; fi; done

