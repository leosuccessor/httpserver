#!/usr/bin/env bash

port=$(bash test_files/get_port.sh)

# Start up server. Using log.txt as audit log file
./httpserver -l "log.txt" $port > /dev/null &
pid=$!

# Wait until we can connect.
while ! nc -zv localhost $port; do
    sleep 0.01
done

#for i in {1..5}; do
    file="test_files/wonderful.txt"
    infile="test_files/createputs.txt"
    outfile="outtemp.txt"


    # This uses random text files and will see if the audit log is same as
    # log from files.
    actual=$(curl -s -w "%{http_code}" -o $outfile localhost:$port/"leo.txt" -T $file)
    actual=$(curl -s -w "%{http_code}" -o $outfile localhost:$port/"test.txt" -T $file)
    actual=$(curl -s -w "%{http_code}" -o $outfile localhost:$port/"hello.txt" -T $file)
    actual=$(curl -s -w "%{http_code}" -o $outfile localhost:$port/"foo.txt" -T $file)


    # Check the diff. All should have code 201 and rq id of 0
    diff "log.txt" $infile
    if [[ $? -ne 0 ]]; then
        # Make sure the server is dead.
        kill -9 $pid
        wait $pid
        rm -f  $outfile "leo.txt" "test.txt" "hello.txt" "foo.txt"
echo "FAIL"
        exit 1
    fi

    # Clean up.
        rm -f $outfile "leo.txt" "test.txt" "hello.txt" "foo.txt"
#done

# Make sure the server is dead.
kill -9 $pid
wait $pid

# Clean up.
        rm -f $outfile "leo.txt" "test.txt" "hello.txt" "foo.txt"

echo "PASS"
exit 0

