//-----------------------------------------------------------------------------
// Leo DeAnda, ledeanda
// 2022 Fall CSE130 Assignment 3
// httpserver.c
// Main file for web server
// With audit log
//-----------------------------------------------------------------------------

#include "bind.h"
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define buffsize 2048
struct stat st;

void get_request(int accepted_socket, char *pathfile, int *stat_code) {
    int file_exist;
    file_exist = open(pathfile, O_RDONLY | O_DIRECTORY);

    // Checks to see if the file actually exists
    if (file_exist == -1) {
        file_exist = open(pathfile, O_RDONLY);
    }

    // If the file does not exist, this results in a not found response
    if (file_exist < 0) {
        if (errno == ENOENT) {
            write(accepted_socket,
                "HTTP/1.1 404 Not Found\r\nContent-Length: 10\r\n\r\nNot Found\n", 56);
            close(file_exist);
            *stat_code = 404;
            return;
        }
    }

    char buff[buffsize];
    int get_file;
    int bytes_wrote;

    // Gets the size of the file
    fstat(file_exist, &st);

    // Reset the buffer, so it is empty.
    memset(buff, 0, buffsize);
    // file_exist = open(pathfile, O_RDONLY, S_IRWXU);
    snprintf(
        (char *) buff, sizeof(buff), "HTTP/1.1 200 OK\r\nContent-Length: %ld\r\n\r\n", st.st_size);
    write(accepted_socket, (char *) buff, strnlen((char *) buff, buffsize));
    *stat_code = 200;

    // Reads from the file name given, and writes to the socket
    while ((get_file = read(file_exist, buff, buffsize)) > 0) {
        bytes_wrote = 0;

        // All bytes could not have gotten written to socket
        while (bytes_wrote < get_file) {
            bytes_wrote += write(accepted_socket, buff, get_file);
        }
    }
    close(file_exist);
    return;
}

void put_request(
    int socket_accepted, int cont_length, char *filepath, char *msgchunk, int *stat_code) {
    int access_to_file, fd;
    uint8_t buff[buffsize + 1] = { 0 };

    // This is to check if the file already exists
    // or we have to create the file.
    access_to_file = access(filepath, F_OK);
    // check for direcrtyor

    int file_status = 0;
    fd = open(filepath, O_WRONLY | O_TRUNC);

    // This is to create the file
    if (fd == -1) {
        fd = open(filepath, O_WRONLY | O_TRUNC | O_CREAT);

        // File status 1 means that the file was just created.
        file_status = 1;
    }

    // This is to print any of the message body if it was
    // apart of the header.
    int read_bytes = 0;
    int msgchunklen = strnlen(msgchunk, buffsize);
    if (msgchunklen > cont_length) {
        write(fd, msgchunk, cont_length);

    } else if (msgchunklen > 0) {
        write(fd, msgchunk, msgchunklen);
    }

    int byteswrritten = msgchunklen;
    int holder;

    // Loop to read through the rest of the message body and write
    // to the file.
    while ((read_bytes = read(socket_accepted, buff, buffsize - 1)) > 0) {
        byteswrritten += read_bytes;

        // If the bytes written is greater than the content length
        // we have to write the amount of bytes, such that it does
        // not go over the content length
        if (byteswrritten >= cont_length) {
            int wantwrite = cont_length - (byteswrritten - read_bytes);
            holder = write(fd, buff, wantwrite);
            break;
        } else {
            holder = write(fd, buff, read_bytes);
        }

        // So it does not hang on read
        if (read_bytes == cont_length) {
            break;
        }
    }

    // Printing the response to socket after writing everything
    // Putting before, causes tests to fail for some reason
    if (file_status == 0) {
        write(socket_accepted, "HTTP/1.1 200 OK\r\nContent-Length: 3\r\n\r\nOK\n", 42);
        *stat_code = 200;
    } else {
        write(socket_accepted, "HTTP/1.1 201 Created\r\nContent-Length: 8\r\n\r\nCreated\n", 52);
        *stat_code = 201;
    }
    // Close file
    close(fd);
    return;

    // These are to write the response http to the socket.
}
void head_request(int accepted_socket, char *pathfile, int *stat_code) {
    int file_exist;
    file_exist = open(pathfile, O_RDONLY | O_DIRECTORY);

    // Checks to see if the file actually exists
    if (file_exist == -1) {
        file_exist = open(pathfile, O_RDONLY);
    }

    // If the file does not exist, this results in a not found response
    if (file_exist < 0) {
        if (errno == ENOENT) {
            write(accepted_socket,
                "HTTP/1.1 404 Not Found\r\nContent-Length: 10\r\n\r\nNot Found\n", 56);
            close(file_exist);
            *stat_code = 404;
            return;
        }
    }

    uint8_t buff[buffsize + 1];
    fstat(file_exist, &st);
    snprintf(
        (char *) buff, sizeof(buff), "HTTP/1.1 200 OK\r\nContent-Length: %ld\r\n\r\n", st.st_size);
    write(accepted_socket, (char *) buff, strnlen((char *) buff, buffsize));
    *stat_code = 200;
}

void write_log(int fd, char *req, char *filename, int rq_id, int stat_code) {

    char buff[buffsize];
    int x = snprintf(buff, buffsize, "%s,%s,%d,%d\n", req, filename, stat_code, rq_id);
    write(fd, buff, x);
}

void parse_request(int accepted_socket, int thread_count, int logfile) {
    thread_count += 0;

    // Some the variables needed for the header
    // The sizes of '8' and '19' were listed
    // in the spec as the max size of the
    // variable. It shows 20 for file path to
    // leave room for '/'
    char req[8] = { 0 }, filepath[20] = { 0 }, version[9] = { 0 }, buff[buffsize + 1] = { 0 },
         buff_hold_holder[buffsize + 1] = { 0 };
    char *string_holder;
    char *random_string_holder = buff;

    int req_read = read(accepted_socket, buff, buffsize);
    memcpy(buff_hold_holder, buff, req_read);

    // Have a buffer holder so that I do not mess with the
    // buff itself
    char *buff_hold = buff_hold_holder;

    // Every properly formatted request will contain '\r\n\r\n'
    // so this if statement is to see if it is present in the header.
    // And/or the header is out of range of 2048

    if ((random_string_holder = strstr(buff, "\r\n\r\n")) == NULL) {

        // This is just to read the rest of the request, already
        // know it is a bad request, but have to read rest of request.
        while ((req_read = read(accepted_socket, buff, buffsize) > 0)) {
            req_read = 1;
        }
        write(accepted_socket,
            "HTTP/1.1 400 Bad Request\r\nContent-Length: 12\r\n\r\nBad Request\n", 61);
        return;
    }

    // The next 3 strtok_r get the 3 request lines
    // and stores them in their respective variables
    string_holder = strtok_r(buff_hold, " ", &buff_hold);
    strncpy(req, string_holder, 8);

    string_holder = strtok_r(buff_hold, " ", &buff_hold);
    strncpy(filepath, string_holder, 20);

    string_holder = strtok_r(buff_hold, "\r\n", &buff_hold);
    strncpy(version, string_holder, 9);

    // threelen refers to the length of the first 3 variables
    // that were just taken. It starts off at 4 because we take
    // into account '\r\n\r\n'.
    int threelen = 4;
    threelen += strnlen(version, 11);
    threelen += strnlen(req, 8);
    threelen += strnlen(filepath, 20);

    // The following is to find the length of the header that
    // we pulled and not include the message body in this length
    // if it happened to be chunked during the read. It checks
    // for the '\r\n\r\n' and will store the length in the variable
    int headerlen = 0;
    for (uint16_t i = 0; i < strnlen(buff, buffsize); i += 1) {
        if (buff[i] == '\n' && buff[i + 1] == '\r') {
            headerlen = i + 3;
            break;
        }
    }

    int stat_code;
    int rq_id = 0;
    int cont_length = -1;

    // something here messes up getting cont length
    while ((buff_hold = strtok_r(string_holder, "\r\n", &string_holder)) != NULL) {

        if (strncmp(buff_hold, "Content-Length", 14) == 0) {
            char *length_holder = buff_hold;
            if ((strtok_r(length_holder, " ", &length_holder)) != NULL) {
                cont_length = atoi(length_holder);

                // This is to check if the content length was only a
                // positive integer. Not a letter or negative
            }
        }

        // This is to get the request id number
        if (strncmp(buff_hold, "Request-Id", 10) == 0) {
            char *length_holder = buff_hold;
            if ((strtok_r(length_holder, " ", &length_holder)) != NULL) {
                rq_id = atoi(length_holder);

                // This is to check if the content length was only a
                // positive integer. Not a letter or negative

                //break;
            }
        }
        // To get rid of the space
        string_holder += 1;
    }

    // This is if the request method was a 'GET'
    if (strncmp(req, "GET", 3) == 0) {
        get_request(accepted_socket, &filepath[1], &stat_code);
        write_log(logfile, "GET", filepath, rq_id, stat_code);
        //fflush(logfile);

    }

    // This is if the request method was a 'PUT'
    else if (strncmp(req, "PUT", 3) == 0) {

        // Use the headerlength found previously to get the message
        // of the request buffer.
        char *msgchunk = &buff[headerlen];
        put_request(accepted_socket, cont_length, &filepath[1], msgchunk, &stat_code);
        write_log(logfile, "PUT", filepath, rq_id, stat_code);
        //fflush(logfile);

    }

    // This is if the request method was a 'HEAD'
    else if (strncmp(req, "HEAD", 4) == 0) {
        head_request(accepted_socket, &filepath[1], &stat_code);
        write_log(logfile, "HEAD", filepath, rq_id, stat_code);
        //fflush(logfile);
    }

    // If it was not GET, PUT, or HEAD that means
    // it is a function that is not implemented

    return;
}

int main(int argc, char *argv[]) {

    // To get the port number
    if (argc < 2) {
        fprintf(stderr, "httpserver: wrong arguments: ./httpserver port_num\nusage: ./httpserver "
                        "[-t threads] [-l logfile] <port>\n");

        return -1;
    }
    int input_int = 0;
    int thread_count = 4;
    int fd;
    char *filepath = NULL;
    while ((input_int = getopt(argc, argv, "t:l:")) > 0) {
        switch (input_int) {
        case 't':
            if (optarg != NULL) {
                thread_count = atoi(optarg);
            }
            break;
        case 'l':
            if (optarg != NULL) {
                filepath = optarg;
            }
            break;
        }
    }

    int socket;
    socket = create_listen_socket(atoi(argv[argc - 1]));

    // Way to check if we opened file or is stderr
    int close_file = 0;
    ///////////////////////////////////////////// CREATE IF DOESNT EXIST
    if (filepath != NULL) {
        fd = open(filepath, O_WRONLY | O_TRUNC);
        close_file = 1;
    } else {
        fd = 2;
    }
    if (fd < 0) {
        //	fprintf(stderr, "File for audit log does not exist.\n");
        //      return -1;
        // throw eerror or make sterr
       //// fd = 2;
       //idk if you create or use stderr ??
       fd = open(filepath, O_WRONLY | O_TRUNC | O_CREAT);
    }
    //////////////////////close FILE
    // If the port number is too small, under 1024

    if (socket == -1) {
        fprintf(stderr, "httpserveer: invalid port number: %s\n", argv[argc - 1]);
        return -1;
    }

    // If the port is already is use
    if (socket == -3) {
        fprintf(stderr, "httpserveer: bind: Permission denied\n");
        return -1;
    }

    // Infinite loop that holds the server up
    for (;;) {
        int accepted_socket = accept(socket, NULL, NULL);
        parse_request(accepted_socket, thread_count, fd);

        // Flush FILEE DESRICPRTIORRRRRRRRRRR
        //
        //
        close(accepted_socket);
    }
}
