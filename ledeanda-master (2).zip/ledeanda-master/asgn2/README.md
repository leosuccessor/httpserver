# Assignment 2 - Bounded Buffer

This program is a queue that acts as a bounded buffer.
It also is multi-thread safe, meaning you can have mulitple\
threads running for the queue, without disrupting any information.
To test my implementation, follow the building portion below.
Once you get 'queue.o' you can run any tests.
Utilizes pthread locks and cond, so that when there are multiple\
threads, they do not overlap at the same time and destroy data.
Also, just normal queue under the multithreaded aspect.

## Building

To make queue.o for testing do:

'''
make
'''

Would be the way to make the queue.o


## Running

Utilize the test scripts to run, or include "queue.h" into a program\
that you want to use the bounded buffer in.
Use the Makefile that was given, if you are trying to test the queue\
functionality itself.
