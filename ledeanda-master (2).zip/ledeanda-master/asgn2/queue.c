#include "queue.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

struct queue {
    uint32_t head;
    uint32_t tail;
    uint32_t size;
    void **objects;
    uint32_t currentsize;

    pthread_mutex_t queuelock;
    pthread_cond_t fullcond;
    pthread_cond_t emptycond;
};

queue_t *queue_new(int size) {
    queue_t *q = (queue_t *) malloc(sizeof(queue_t));
    if (q) {
        pthread_mutex_init(&q->queuelock, NULL);
        pthread_cond_init(&q->fullcond, NULL);
        pthread_cond_init(&q->emptycond, NULL);
        q->size = size;
        q->currentsize = 0;
        q->head = 0;
        q->tail = -1;

        q->objects = malloc(sizeof(void *) * size);

        if (!q->objects) {
            free(q);
            q = NULL;
        }
    }
    return q;
}
void queue_delete(queue_t **q) {
    if (*q && (*q)->objects) {
        pthread_mutex_destroy(&(*q)->queuelock);
        pthread_cond_destroy(&(*q)->fullcond);
        pthread_cond_destroy(&(*q)->emptycond);
        free((*q)->objects);
        free(*q);
        *q = NULL;
    }
    return;
}

bool queue_push(queue_t *q, void *elem) {

    // Check to see that q is not null
    if (q == NULL) {
        return false;
    }

    pthread_mutex_lock(&q->queuelock);

    // Blocks iif the current size is same as size, since
    // there is no room to push
    while (q->currentsize == q->size) {
        // Will continue once signalled from the full
        // condition
        pthread_cond_wait(&q->fullcond, &q->queuelock);
    }
    q->tail = (q->tail + 1) % q->size;
    q->objects[q->tail] = elem;
    q->currentsize += 1;

    pthread_cond_signal(&q->emptycond);
    pthread_mutex_unlock(&q->queuelock);

    return true;
}
bool queue_pop(queue_t *q, void **elem) {

    // Check to see that q is not null
    if (q == NULL) {
        return false;
    }

    pthread_mutex_lock(&q->queuelock);

    // Blocks iif the current size is 0, since
    // there is nothing to pop off
    while (q->currentsize == 0) {
        // Will continue once signaled from the empty
        // condition
        pthread_cond_wait(&q->emptycond, &q->queuelock);
    }
    *elem = q->objects[q->head];
    q->head = (q->head + 1) % q->size;
    q->currentsize -= 1;

    pthread_cond_signal(&q->fullcond);
    pthread_mutex_unlock(&q->queuelock);

    return true;
}
