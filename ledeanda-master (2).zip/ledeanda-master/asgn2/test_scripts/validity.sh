# This tests the validity as stated in the spec.
# If a thread enqueues a, and another thread dequeues a,
# and another thread enqueues a, any other consumer does not
# read any junk
cleanup(){
	rm -r test_dir
}

QUEUE="queue.o queue.h"
TEST_FILES="test_files/validity_test.c test_files/Makefile"

mkdir test_dir

cp $QUEUE test_dir
cp $TEST_FILES test_dir

make -C test_dir

./test_dir/queue-test 10

if [ $? != 0 ]
then
	echo "bad exit"
	cleanup
	exit 1
fi

cleanup

