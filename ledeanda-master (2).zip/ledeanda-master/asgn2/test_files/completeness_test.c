#include "queue.h"

#include <pthread.h>
#include <unistd.h>

void *thread1(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];

  // Pushing different thinngs onto the queue
  queue_push(q, (void *)1);
  queue_push(q, (void *)"TESTING");
  queue_push(q, (void *)433223);
  queue_push(q, (void *)"aldaw");
  queue_push(q, (void *)3939);
  queue_push(q, (void *)83);
  queue_push(q, (void *)51);
  queue_push(q, (void *)"hello world");
  queue_push(q, (void *)'c');

  *v = 1;

  pthread_cond_signal(c);
  return NULL;
}

void *thread2(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
  if (!*v) {
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&mutex);
    pthread_cond_wait(c, &mutex);
    pthread_mutex_unlock(&mutex);
  }

  void *r = NULL;

  // This is to show that after some time of popping
  // it eventually gets one of the elements that was pushed onto the 
  // queue.
  while((int)r != 3939){
	queue_pop(q, &r);
  }
  return NULL;
}

int main(int argc, char **argv) {
  (void)argc;
  (void)argv;
  queue_t *q = queue_new(10);
  if (q == NULL) {
    return 1;
  }
  pthread_t t1, t2;

  pthread_cond_t c;
  pthread_cond_init(&c, NULL);
  int v = 0;

  void *args[3] = {q, &c, &v};

  pthread_create(&t1, NULL, thread1, args);
  pthread_create(&t2, NULL, thread2, args);

  void *rc;
  pthread_join(t1, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t2, &rc);
  if (rc != NULL)
    return 1;

  queue_delete(&q);
  return 0;
}

