#include "queue.h"

#include <pthread.h>
#include <unistd.h>


int one[3] = {1,2,3};
int two[3] = {10,20,30};
int three[3] = {100,200,300};

void *thread1(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
  queue_push(q, (void *)1);
  queue_push(q, (void *)2);
  queue_push(q, (void *)3);

  *v = 1;

  pthread_cond_signal(c);
  return NULL;
}

void *thread3(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];

  queue_push(q, (void *)10);
  queue_push(q, (void *)20);
  queue_push(q, (void *)30);
  *v = 1;

  pthread_cond_signal(c);
  return NULL;
}

void *thread4(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
  queue_push(q, (void *)100);
  queue_push(q, (void *)200);
  queue_push(q, (void *)300);

  *v = 1;

  pthread_cond_signal(c);
  return NULL;
}


void *thread2(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
  if (!*v) {
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&mutex);
    pthread_cond_wait(c, &mutex);
    pthread_mutex_unlock(&mutex);
  }


  // So this tests for FIFO because i arranged it so that all the
  // ints that are pushed onto the queue are from smallest to largest.
  // So if at any point the second pop is larger than the first pop, that 
  // means some of the numbers got mixed up somewhere. If it can get through
  // the loop without returning 1, that means it holds true to the FIFO
  // order.
  void *r;
  void *n;
  void *x;
  for(int i = 0; i < 3; i += 1){
	  queue_pop(q, &r);
	  queue_pop(q, &n);
	  queue_pop(q, &x);
	  for(int j = 1; j < 3; j += 1){
		if((int)r == one[j] && (int)n == one[j-1]){
			return (void *) 1;
		}
		if((int)r == two[j] && (int)n == two[j-1]){
                        return (void *) 1;
                }
		if((int)r == three[j] && (int)n == three[j-1]){
                        return (void *) 1;
                }

	  }

  }
  return NULL;
}

int main(int argc, char **argv) {
  (void)argc;
  (void)argv;
  queue_t *q = queue_new(15);
  if (q == NULL) {
    return 1;
  }
  pthread_t t1, t2, t3, t4;

  pthread_cond_t c;
  pthread_cond_init(&c, NULL);
  int v = 0;

  void *args[3] = {q, &c, &v};

  pthread_create(&t1, NULL, thread1, args);
  pthread_create(&t2, NULL, thread2, args);
  pthread_create(&t3, NULL, thread3, args);
  pthread_create(&t4, NULL, thread4, args);

  void *rc;
  pthread_join(t1, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t2, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t3, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t4, &rc);
  if (rc != NULL)
    return 1;
  queue_delete(&q);
  return 0;
}

