#include "queue.h"

#include <pthread.h>
#include <unistd.h>

void *thread1(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
  queue_push(q, (void *)1);
  queue_push(q, (void *)4321);
  queue_push(q, (void *)111);
pthread_cond_signal(c);

  *v = 1;

  return NULL;
}
void *thread2(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
  queue_push(q, (void *)1);
  queue_push(q, (void *)4321);
  queue_push(q, (void *)111);
pthread_cond_signal(c);

  *v = 1;

  return NULL;
}
void *thread3(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
  queue_push(q, (void *)1);
  queue_push(q, (void *)4321);
  queue_push(q, (void *)111);
pthread_cond_signal(c);

  *v = 1;

  return NULL;
}

void *thread11(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
 if (!*v) {
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&mutex);
    pthread_cond_wait(c, &mutex);
    pthread_mutex_unlock(&mutex);
  }

  void *r;
  *v = 1;
  queue_pop(q, &r);
  return NULL;
}
void *thread12(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
 if (!*v) {
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&mutex);
    pthread_cond_wait(c, &mutex);
    pthread_mutex_unlock(&mutex);
  }

  void *r;
  *v = 1;
  queue_pop(q, &r);
  return NULL;
}

void *thread13(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
 if (!*v) {
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&mutex);
    pthread_cond_wait(c, &mutex);
    pthread_mutex_unlock(&mutex);
  }

  void *r;
  *v = 1;
  queue_pop(q, &r);
  return NULL;
}



int main(int argc, char **argv) {
  (void)argc;
  (void)argv;
  queue_t *q = queue_new(21);
  if (q == NULL) {
    return 1;
  }
  pthread_t t1, t2, t3, t11, t12, t13;

  pthread_cond_t c;
  pthread_cond_init(&c, NULL);
  int v = 0;

  void *args[3] = {q, &c, &v};

  pthread_create(&t1, NULL, thread1, args);
  pthread_create(&t2, NULL, thread2, args);
  pthread_create(&t3, NULL, thread3, args);
  pthread_create(&t11, NULL, thread11, args);
  pthread_create(&t12, NULL, thread12, args);
  pthread_create(&t13, NULL, thread13, args);

  void *rc;
  pthread_join(t1, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t2, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t3, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t11, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t12, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t13, &rc);
  if (rc != NULL)
    return 1;

  queue_delete(&q);
  return 0;
}


