#include "queue.h"

#include <pthread.h>
#include <unistd.h>
#include <stdio.h>

void *thread1(void *args) {
  queue_t *q = ((void **)args)[0];
  int *v = ((void **)args)[2];
  
  // Trying to push 10 onto the queue even though it is
  // full.
  queue_push(q, (void *)619);


  *v = 1;

  return NULL;
}

void *thread2(void *args) {
  queue_t *q = ((void **)args)[0];
  int *v = ((void **)args)[2];

  void *r;
  
  queue_pop(q, &r);
  *v = 1;
  if((int)r != 14){
	return (void *)1;
  }
  return NULL;
}

int main(int argc, char **argv) {
  (void)argc;
  (void)argv;
  queue_t *q = queue_new(1);
  if (q == NULL) {
    return 1;
  }
  pthread_t t1, t2;

  pthread_cond_t c;
  pthread_cond_init(&c, NULL);
  int v = 0;

  void *args[3] = {q, &c, &v};

  // Size of queue is 1, so pushing 14 onto the queue
  // makes it full.
  // Then we try to push using the thread.
  queue_push(q, (void *) 14);
  sleep(1);
  pthread_create(&t1, NULL, thread1, args);

  // Sleep to wait to see if anything happens
  sleep(1);

  // Then we pop and check if the thread 1 was able to
  // push 619 onto the queue
  pthread_create(&t2, NULL, thread2, args);
  sleep(1);

  void *r;

  queue_pop(q, &r);
  if((int)r != 619){
	return 1;
  }

  void *rc;
  pthread_join(t1, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t2, &rc);
  if (rc != NULL)
    return 1;

  queue_delete(&q);
  return 0;
}

