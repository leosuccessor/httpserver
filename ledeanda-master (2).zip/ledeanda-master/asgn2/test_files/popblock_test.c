#include "queue.h"

#include <pthread.h>
#include <unistd.h>
#include <stdio.h>

void *thread1(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];
  if (!*v) {
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&mutex);
    pthread_cond_wait(c, &mutex);
    pthread_mutex_unlock(&mutex);
  }
  
  // We just push stuff onto the queue after
  // waiting for pop. Just to see that it works.
  queue_push(q, (void *)9999);
  queue_push(q, (void *)-121321);
  queue_push(q, (void *)6);
  queue_push(q, (void *)"name");
  queue_push(q, (void *)"date");
  queue_push(q, (void *)"-2)@)(");

  *v = 1;

  pthread_cond_signal(c);
  return NULL;
}

void *thread2(void *args) {
  queue_t *q = ((void **)args)[0];
  pthread_cond_t *c = ((void **)args)[1];
  int *v = ((void **)args)[2];

  void *r;

  // Pop should be handing since there was nothing to pop at first.
  // Afterwards we check that it was the correct item popped off.
  queue_pop(q, &r);
  *v = 1;

  pthread_cond_signal(c);
  if ((int)r != 9999) {
    // if not, then we failed
    return (void *)1;
  }
  return NULL;
}

int main(int argc, char **argv) {
  (void)argc;
  (void)argv;
  queue_t *q = queue_new(10);
  if (q == NULL) {
    return 1;
  }
  pthread_t t1, t2;

  pthread_cond_t c;
  pthread_cond_init(&c, NULL);
  int v = 0;

  void *args[3] = {q, &c, &v};

  // Popping on an empty queue at first to see that
  // it will block
  pthread_create(&t2, NULL, thread2, args);

  // Just wait to see that nothing happens while waiting.
  sleep(3);

  // Push 9999 onto the queue to see if thread 2 will be successful
  // after waiting in the block
  queue_push(q, (void *)9999);
  pthread_create(&t1, NULL, thread1, args);

  void *rc;
  pthread_join(t1, &rc);
  if (rc != NULL)
    return 1;
  pthread_join(t2, &rc);
  if (rc != NULL)
    return 1;

  queue_delete(&q);
  return 0;
}

